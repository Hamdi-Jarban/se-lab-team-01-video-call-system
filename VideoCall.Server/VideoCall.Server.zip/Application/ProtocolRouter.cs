using VideoCall.Server.Domain;
using VideoCall.Server.Domain.Logging;
using VideoCall.Server.Domain.Repositories;
using VideoCall.Server.Domain.Services;
using VideoCall.Shared.Messages;
using System.Collections.Concurrent;
using VideoCall.Shared.Models;

namespace VideoCall.Server.Application;

/// <summary>
/// ����� ����� �������� TCP ��� �������� �������� ���� ������ޡ
/// ��� ����� ������ ���������� ������ �����.
/// ����� ��� ������ Domain ��� ������ �� Socket ������.
/// </summary>
public sealed class ProtocolRouter : IProtocolMessageDispatcher, IConnectionLifecycleHandler
{
    private readonly IUserPresenceRepository _presence;
    private readonly IConversationRepository _conversations;
    private readonly IMediaRelayCoordinator _media;
    private readonly IAuthService _auth;
    private readonly LoginThrottle _throttle;
    private readonly ChatProtocolHandler _chat;
    private readonly ICallHistoryRecorder _callHistory;
    private readonly IAppLogger _logger;
    private readonly ConcurrentDictionary<Guid, PendingRoomInvite> _pendingInvites = new();

    private sealed record PendingRoomInvite(Guid InviteId, string RoomId, string Host, string Invitee);

    public ProtocolRouter(
        IUserPresenceRepository presence,
        IConversationRepository conversations,
        IMediaRelayCoordinator media,
        IAuthService auth,
        LoginThrottle throttle,
        ChatProtocolHandler chat,
        ICallHistoryRecorder callHistory,
        IAppLogger logger)
    {
        _presence = presence ?? throw new ArgumentNullException(nameof(presence));
        _conversations = conversations ?? throw new ArgumentNullException(nameof(conversations));
        _media = media ?? throw new ArgumentNullException(nameof(media));
        _auth = auth ?? throw new ArgumentNullException(nameof(auth));
        _throttle = throttle ?? throw new ArgumentNullException(nameof(throttle));
        _chat = chat ?? throw new ArgumentNullException(nameof(chat));
        _callHistory = callHistory ?? throw new ArgumentNullException(nameof(callHistory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task DispatchAsync(IClientHandler session, Message message, CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(session);
        ArgumentNullException.ThrowIfNull(message);

        // رسائل المراسلة الدائمة تُعالج في ChatProtocolHandler (فصل المسؤوليات)
        if (ChatProtocolHandler.CanHandle(message.Type))
        {
            await _chat.HandleAsync(session, message, ct);
            return;
        }

        switch (message.Type)
        {
            case MessageType.RegisterRequest:
                await RegisterAsync(session, message.ReadPayload<RegisterRequestPayload>(), ct);
                return;

            case MessageType.LoginRequest:
                await LoginAsync(session, message.ReadPayload<LoginRequestPayload>(), ct);
                return;

            case MessageType.CallRequest:
                await RequestPrivateCallAsync(session, message.ReadPayload<CallRequestPayload>(), ct);
                return;

            case MessageType.CallAccepted:
                await AcceptPrivateCallAsync(session, message.ReadPayload<CallAcceptedPayload>(), ct);
                return;

            case MessageType.CallRejected:
                await RejectPrivateCallAsync(session, message.ReadPayload<CallRejectedPayload>(), ct);
                return;

            case MessageType.CallEnded:
                await EndPrivateCallAsync(session, message.ReadPayload<CallEndedPayload>(), ct);
                return;

            case MessageType.CreateRoomRequest:
                await CreateRoomAsync(session, message.ReadPayload<CreateRoomRequestPayload>(), ct);
                return;

            case MessageType.AddUserToRoomRequest:
                await AddUserToRoomAsync(session, message.ReadPayload<AddUserToRoomRequestPayload>(), ct);
                return;

            case MessageType.RoomInviteAccepted:
                await AcceptRoomInviteAsync(session, message.ReadPayload<RoomInviteAcceptedPayload>(), ct);
                return;

            case MessageType.RoomInviteRejected:
                await RejectRoomInviteAsync(session, message.ReadPayload<RoomInviteRejectedPayload>(), ct);
                return;

            case MessageType.JoinRoomRequest:
                await JoinRoomAsync(session, message.ReadPayload<JoinRoomRequestPayload>(), ct);
                return;

            case MessageType.LeaveRoomRequest:
                await LeaveConversationAsync(session, message.ReadPayload<LeaveRoomRequestPayload>(), ct);
                return;

            case MessageType.StartRoomMedia:
                await StartGroupMediaAsync(session, message.ReadPayload<StartRoomMediaPayload>(), ct);
                return;

            case MessageType.StopRoomMedia:
                await StopGroupMediaAsync(session, message.ReadPayload<StopRoomMediaPayload>(), ct);
                return;

            case MessageType.Disconnect:
                await session.CloseAsync();
                return;

            default:
                await SendErrorAsync(session, ErrorCodes.UnexpectedError, "Unsupported message type.", ct);
                return;
        }
    }

    private async Task LoginAsync(IClientHandler session, LoginRequestPayload? request, CancellationToken ct)
    {
        if (request is null || session.IsAuthenticated)
        {
            await SendErrorAsync(session, ErrorCodes.InvalidCredentials, "Invalid login request.", ct);
            return;
        }

        var requestedUsername = request.Username?.Trim();
        if (string.IsNullOrWhiteSpace(requestedUsername) || requestedUsername.Length > 64)
        {
            await SendLoginFailureAsync(session, ErrorCodes.InvalidCredentials, ct);
            return;
        }

        if (_throttle.IsLocked(requestedUsername))
        {
            await SendLoginFailureAsync(session, ErrorCodes.TooManyAttempts, ct);
            return;
        }

        // 1) التحقق من الحساب وكلمة المرور من SQL Server
        AuthenticationResult auth;
        try
        {
            auth = await _auth.AuthenticateAsync(requestedUsername, request.Password ?? string.Empty, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.Error($"Login failed because the database is unavailable: {ex.Message}");
            await SendLoginFailureAsync(session, ErrorCodes.ServerUnavailable, ct);
            return;
        }

        if (!auth.Success)
        {
            _throttle.RegisterFailure(requestedUsername);
            await SendLoginFailureAsync(session, ErrorCodes.InvalidCredentials, ct);
            return;
        }

        _throttle.Reset(requestedUsername);

        // 2) الحضور (Online Presence) يبقى في الذاكرة لأنه حالة Runtime، لكنه مرتبط بمستخدم موجود في SQL
        if (!_presence.TryAdd(auth.Username, session))
        {
            await SendLoginFailureAsync(session, ErrorCodes.AlreadyLoggedIn, ct);
            return;
        }

        // نربط الجلسة بالمستخدم فورًا (قبل أي await) حتى يُنظَّف الحضور تلقائيًا لو انقطع الاتصال الآن
        session.SetAuthenticatedUser(auth.UserId, auth.Username);

        // 3) تسجيل الجلسة في UserSessions وتحديث LastLoginAt
        try
        {
            await _auth.StartSessionAsync(session.SessionToken, auth.UserId, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.Error($"Could not create the session row for {auth.Username}: {ex.Message}");
            await SendLoginFailureAsync(session, ErrorCodes.ServerUnavailable, ct);
            await session.CloseAsync();
            return;
        }

        _logger.Info($"{auth.Username} logged in.");
        await session.SendAsync(Message.Create(
            MessageType.LoginResponse,
            new LoginResponsePayload(true, null, auth.Username, session.SessionToken)), ct);

        await BroadcastPresenceAsync(ct);
    }

    private async Task RegisterAsync(IClientHandler session, RegisterRequestPayload? request, CancellationToken ct)
    {
        if (request is null || session.IsAuthenticated)
        {
            await session.SendAsync(Message.Create(
                MessageType.RegisterResponse,
                new RegisterResponsePayload(false, ErrorCodes.InvalidRequest, null)), ct);
            return;
        }

        RegisterResult result;
        try
        {
            result = await _auth.RegisterAsync(request.Username ?? string.Empty, request.Password ?? string.Empty, request.DisplayName, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.Error($"Registration failed because the database is unavailable: {ex.Message}");
            result = RegisterResult.Fail(ErrorCodes.ServerUnavailable);
        }

        if (result.Success) _logger.Info($"{result.Username} registered.");

        await session.SendAsync(Message.Create(
            MessageType.RegisterResponse,
            new RegisterResponsePayload(result.Success, result.ErrorCode, result.Username)), ct);
    }

    private static Task SendLoginFailureAsync(IClientHandler session, string errorCode, CancellationToken ct) =>
        session.SendAsync(Message.Create(
            MessageType.LoginResponse,
            new LoginResponsePayload(false, errorCode, null, null)), ct);

    private async Task RequestPrivateCallAsync(IClientHandler session, CallRequestPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var caller) || request is null) return;
        var callee = request.Callee?.Trim();
        if (string.IsNullOrWhiteSpace(callee) || caller.Equals(callee, StringComparison.OrdinalIgnoreCase)) return;
        if (!_presence.IsOnline(callee))
        {
            await SendErrorAsync(session, ErrorCodes.TargetOffline, "The target user is offline.", ct);
            return;
        }

        var callId = Guid.NewGuid();
        var result = _conversations.CreatePrivate(callId.ToString("N"), caller, callee, out _);
        if (result != ConversationOperation.Success)
        {
            await SendErrorAsync(session, ErrorCodes.TargetBusy, "The private conversation could not be created.", ct);
            return;
        }

        var callRequestMessage = Message.Create(
            MessageType.CallRequest,
            new CallRequestPayload(callId, caller, callee));
        await SendToUserAsync(callee, callRequestMessage, ct);
        // ����� ���� �������� ���� ����� ������ ��� ������.
        await SendToUserAsync(caller, callRequestMessage, ct);

        // سجل المكالمات في SQL (لا يؤثر فشله على المكالمة)
        await _callHistory.PrivateCallStartedAsync(callId, session.UserId);
    }

    private async Task AcceptPrivateCallAsync(IClientHandler session, CallAcceptedPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var username) || request is null) return;
        var id = request.CallId.ToString("N");
        var result = _conversations.ActivateMedia(id, username, out _);
        if (result != ConversationOperation.Success)
        {
            await SendErrorAsync(session, ErrorCodes.InvalidCallState, "The call cannot be accepted.", ct);
            return;
        }

        await SendToUserAsync(request.Caller, Message.Create(
            MessageType.CallAccepted,
            new CallAcceptedPayload(request.CallId, request.Caller, username)), ct);
        await StartMediaForConversationAsync(id, ct);
        _ = _callHistory.StatusChangedAsync(request.CallId, CallStatus.Connected);
    }

    private async Task RejectPrivateCallAsync(IClientHandler session, CallRejectedPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var username) || request is null) return;
        var id = request.CallId.ToString("N");
        var result = _conversations.EndPrivate(id, username, out var members);
        if (result != ConversationOperation.Success) return;

        _media.ForgetConversation(id);
        _ = _callHistory.StatusChangedAsync(request.CallId, CallStatus.Rejected);
        var message = Message.Create(
            MessageType.CallRejected,
            new CallRejectedPayload(request.CallId, request.Caller, username));
        foreach (var member in members.Where(x => !x.Equals(username, StringComparison.OrdinalIgnoreCase)))
            await SendToUserAsync(member, message, ct);
    }

    private async Task EndPrivateCallAsync(IClientHandler session, CallEndedPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var username) || request is null) return;
        var id = request.CallId.ToString("N");
        var result = _conversations.EndPrivate(id, username, out var members);
        if (result != ConversationOperation.Success) return;

        _media.ForgetConversation(id);
        _ = _callHistory.StatusChangedAsync(request.CallId, CallStatus.Ended);
        var message = Message.Create(MessageType.CallEnded, new CallEndedPayload(request.CallId, username));
        foreach (var member in members.Where(x => !x.Equals(username, StringComparison.OrdinalIgnoreCase)))
            await SendToUserAsync(member, message, ct);
    }

    private async Task CreateRoomAsync(IClientHandler session, CreateRoomRequestPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var username) || request is null) return;
        var id = request.RoomId?.Trim();
        var result = _conversations.CreateGroup(id ?? string.Empty, username, out var conversation);
        if (result != ConversationOperation.Success || conversation is null)
        {
            await SendRoomErrorAsync(session, result, ct);
            return;
        }

        await BroadcastConversationUpdateAsync(conversation, ct);
    }

    private async Task AddUserToRoomAsync(IClientHandler session, AddUserToRoomRequestPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var host) || request is null) return;
        var invitee = request.Username?.Trim();
        if (string.IsNullOrWhiteSpace(invitee) || !_presence.IsOnline(invitee))
        {
            await SendErrorAsync(session, ErrorCodes.UserNotFound, "The invited user is offline.", ct);
            return;
        }
        if (!_conversations.TryGet(request.RoomId, out var room) || room is null ||
            !room.Host.Equals(host, StringComparison.OrdinalIgnoreCase))
        {
            await SendRoomErrorAsync(session, ConversationOperation.NotHost, ct);
            return;
        }
        var inviteId = Guid.NewGuid();
        var pending = new PendingRoomInvite(inviteId, room.Id, host, invitee);
        _pendingInvites[inviteId] = pending;
        await SendToUserAsync(invitee, Message.Create(MessageType.RoomInvite,
            new RoomInvitePayload(inviteId, room.Id, host, invitee)), ct);
    }

    private async Task AcceptRoomInviteAsync(IClientHandler session, RoomInviteAcceptedPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var invitee) || request is null ||
            !_pendingInvites.TryRemove(request.InviteId, out var pending) ||
            !pending.Invitee.Equals(invitee, StringComparison.OrdinalIgnoreCase)) return;

        var result = _conversations.AddMember(pending.RoomId, pending.Host, invitee, out var conversation);
        if (result != ConversationOperation.Success && result != ConversationOperation.AlreadyMember)
        {
            await SendRoomErrorAsync(session, result, ct);
            return;
        }
        if (conversation is not null)
        {
            await BroadcastConversationUpdateAsync(conversation, ct);
            await SendToUserAsync(pending.Host, Message.Create(MessageType.RoomInviteAccepted,
                new RoomInviteAcceptedPayload(pending.InviteId, pending.RoomId, invitee)), ct);
        }
    }

    private async Task RejectRoomInviteAsync(IClientHandler session, RoomInviteRejectedPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var invitee) || request is null ||
            !_pendingInvites.TryRemove(request.InviteId, out var pending) ||
            !pending.Invitee.Equals(invitee, StringComparison.OrdinalIgnoreCase)) return;
        await SendToUserAsync(pending.Host, Message.Create(MessageType.RoomInviteRejected,
            new RoomInviteRejectedPayload(pending.InviteId, pending.RoomId, invitee)), ct);
    }

    private async Task JoinRoomAsync(IClientHandler session, JoinRoomRequestPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var username) || request is null) return;
        var result = _conversations.Join(request.RoomId, username, out var conversation);
        if (result is not (ConversationOperation.Success or ConversationOperation.AlreadyMember) || conversation is null)
        {
            await SendRoomErrorAsync(session, result, ct);
            return;
        }

        await BroadcastConversationUpdateAsync(conversation, ct);
    }

    private async Task LeaveConversationAsync(IClientHandler session, LeaveRoomRequestPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var username) || request is null) return;
        var result = _conversations.Leave(request.RoomId, username, out var conversation, out var removed);
        if (result != ConversationOperation.Success)
        {
            await SendRoomErrorAsync(session, result, ct);
            return;
        }

        _media.RemoveEndpoint(request.RoomId, username);
        if (removed) _media.ForgetConversation(request.RoomId);
        else if (conversation is not null) await BroadcastConversationUpdateAsync(conversation, ct);
    }

    private async Task StartGroupMediaAsync(IClientHandler session, StartRoomMediaPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var username) || request is null) return;
        var result = _conversations.StartMedia(request.RoomId, username, out var conversation);
        if (result != ConversationOperation.Success || conversation is null)
        {
            await SendErrorAsync(session, ErrorCodes.NotRoomMember, "Only the host can start this conversation.", ct);
            return;
        }
        await StartMediaForConversationAsync(conversation.Id, ct);

        if (conversation.MediaId is Guid roomCallId)
            await _callHistory.RoomCallStartedAsync(roomCallId, conversation.Id, session.UserId);
    }

    private async Task StopGroupMediaAsync(IClientHandler session, StopRoomMediaPayload? request, CancellationToken ct)
    {
        if (!RequireAuthenticated(session, out var username) || request is null) return;
        _conversations.TryGet(request.RoomId, out var beforeStop);
        var result = _conversations.StopMedia(request.RoomId, username, out var conversation);
        if (result != ConversationOperation.Success || conversation is null) return;

        _media.ForgetConversation(conversation.Id);
        if (beforeStop?.MediaId is Guid stoppedCallId)
            _ = _callHistory.StatusChangedAsync(stoppedCallId, CallStatus.Ended);
        var message = Message.Create(MessageType.RoomMediaStopped,
            new RoomMediaPayload(conversation.Id, beforeStop?.MediaId ?? Guid.Empty));
        await SendToConversationAsync(conversation.Id, message, ct);
    }

    private async Task StartMediaForConversationAsync(string conversationId, CancellationToken ct)
    {
        if (!_conversations.TryGet(conversationId, out var activeConversation) || activeConversation.MediaId is not Guid mediaId)
            return;
        var message = Message.Create(MessageType.RoomMediaStarted,
            new RoomMediaPayload(conversationId, mediaId));
        await SendToConversationAsync(conversationId, message, ct);
    }

    private async Task BroadcastConversationUpdateAsync(Conversation conversation, CancellationToken ct)
    {
        await SendToConversationAsync(conversation.Id,
            Message.Create(MessageType.RoomUpdate,
                new RoomUpdatePayload(conversation.Id, conversation.Host, conversation.Members.ToList())), ct);
    }

    private async Task SendToConversationAsync(string conversationId, Message message, CancellationToken ct)
    {
        foreach (var member in _conversations.GetMembersSnapshot(conversationId))
            await SendToUserAsync(member, message, ct);
    }

    /// <summary>
    /// ���� ����� ���� TCP ��� ������ ������ ��� ����� ������
    /// ������ �������� �� ��������� ������ ������� ��������.
    /// </summary>
    public async Task HandleDisconnectAsync(IClientHandler session, CancellationToken ct)
    {
        if (session.Username is null) return;
        _presence.Remove(session.Username, session);

        // إغلاق سجل الجلسة في SQL (IsActive = 0, DisconnectedAt = NOW)
        try
        {
            await _auth.EndSessionAsync(session.SessionToken, CancellationToken.None);
        }
        catch (Exception ex)
        {
            _logger.Warn($"Could not close the SQL session for {session.Username}: {ex.Message}");
        }

        foreach (var conversation in _conversations.RemoveUserFromAll(session.Username))
        {
            _media.RemoveEndpoint(conversation.Id, session.Username);
            await BroadcastConversationUpdateAsync(conversation, ct);
        }

        await BroadcastPresenceAsync(ct);
    }

    private async Task BroadcastPresenceAsync(CancellationToken ct)
    {
        var message = Message.Create(
            MessageType.OnlineUsersUpdate,
            new OnlineUsersUpdatePayload(_presence.GetUsernames().ToList()));
        foreach (var session in _presence.GetSessions())
        {
            try { await session.SendAsync(message, ct); }
            catch { /* ��� ����� ������ �� ���� ClientSession. */ }
        }
    }

    /// <summary>
    /// ����� ����� ����� ��� ������ ���ϡ ����� ����� ��� ���� �������.
    /// </summary>
    private async Task SendToUserAsync(string username, Message message, CancellationToken ct)
    {
        if (!_presence.TryGet(username, out var session)) return;
        try
        {
            await session.SendAsync(message, ct);
        }
        catch (Exception ex)
        {
            _logger.Warn($"Could not send {message.Type} to {username}: {ex.Message}");
        }
    }

    private async Task SendRoomErrorAsync(IClientHandler session, ConversationOperation result, CancellationToken ct)
    {
        var (code, text) = result switch
        {
            ConversationOperation.AlreadyExists => (ErrorCodes.RoomAlreadyExists, "Room already exists."),
            ConversationOperation.NotFound => (ErrorCodes.RoomNotFound, "Room not found."),
            ConversationOperation.NotMember => (ErrorCodes.NotRoomMember, "You are not a room member."),
            ConversationOperation.Full => (ErrorCodes.RoomFull, "Room is full."),
            _ => (ErrorCodes.UnexpectedError, "Unexpected room error.")
        };
        await session.SendAsync(Message.Create(MessageType.RoomError,
            new RoomErrorPayload(code, text)), ct);
    }

    private static async Task SendErrorAsync(IClientHandler session, string code, string text, CancellationToken ct)
    {
        await session.SendAsync(Message.Create(MessageType.Error, new ErrorPayload(code, text)), ct);
    }

    private static bool RequireAuthenticated(IClientHandler session, out string username)
    {
        username = session.Username ?? string.Empty;
        return !string.IsNullOrWhiteSpace(username);
    }
}
